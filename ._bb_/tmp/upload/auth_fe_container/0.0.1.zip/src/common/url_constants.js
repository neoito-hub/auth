const url_constants = {
  LOGIN: "/login",
  VERIFY_EMAIL: "/verify_email",
  RESET_PASSWORD: "/reset_password",
  FORGOT_PASSWORD: "/forgot_password",
};
export default url_constants;
