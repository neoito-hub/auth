export default {
  "./auth_fe_verify_email": "./src/remote/auth_fe_verify_email",
};
