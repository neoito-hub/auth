import React from "react";
import VerifyEmail from "./remote/VerifyEmail";

export default function App() {
  return (
    <div className="App" data-testid="app">
      <VerifyEmail />
    </div>
  );
}
